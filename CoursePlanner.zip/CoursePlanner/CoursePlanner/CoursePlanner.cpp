#include <iostream>
#include <vector>
#include <algorithm>  // Required for the find_if function

// Define the Course structure
struct Course {
    std::string courseNumber;                  // Course number, e.g., "CSCI100"
    std::string title;                         // Course title, e.g., "Introduction to Computer Science"
    std::vector<std::string> prerequisites;    // List of course numbers that are prerequisites
};

// Hardcoded courses data for simplicity
std::vector<Course> courses = {
    {"CSCI100", "Introduction to Computer Science", {}},
    {"MATH201", "Discrete Mathematics", {}},
    {"CSCI101", "Introduction to Programming in C++", {"CSCI100"}},
    {"CSCI200", "Data Structures", {"CSCI101"}},
    {"CSCI300", "Introduction to Algorithms", {"CSCI200", "MATH201"}},
    {"CSCI301", "Advanced Programming in C++", {"CSCI101"}},
    {"CSCI350", "Operating Systems", {"CSCI300"}},
    {"CSCI400", "Large Software Development", {"CSCI301", "CSCI350"}}
};

// Function to display the main menu to the user
int displayMenu() {
    int choice;
    std::cout << "\nWelcome to the course planner." << std::endl;
    std::cout << "1. Load Data Structure." << std::endl;
    std::cout << "2. Print Course List." << std::endl;
    std::cout << "3. Print Course." << std::endl;
    std::cout << "9. Exit" << std::endl;
    std::cout << "What would you like to do? ";
    std::cin >> choice;
    return choice;

    // Check if the input operation was successful to prevent errors from invalid input
    if (std::cin.fail()) {
        std::cin.clear(); // Clear the previous input
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Disregard the previous input
        return -1; // Return an invalid option
    }

    return choice;

}

int main() {
    int option;

    // Main loop to keep the program running until the user exits
    while ((option = displayMenu()) != 9) {
        switch (option) {
        case 1:
            // Data is hardcoded, so this option simply acknowledges the user's request
            std::cout << "Courses are already loaded." << std::endl;
            break;

        case 2:
            // Loop through the courses and display their number and title
            for (const Course& course : courses) {
                std::cout << course.courseNumber << ": " << course.title << std::endl;

                // Check if the course has prerequisites and display them
                if (!course.prerequisites.empty()) {
                    std::cout << "  Prerequisites: ";
                    for (const std::string& prereq : course.prerequisites) {
                        std::cout << prereq << " ";
                    }
                    std::cout << std::endl;
                }
            }
            break;

        case 3:
        {
            std::string courseNum;
            std::cout << "Enter the course number (e.g., CSCI100): ";
            std::cin >> courseNum;

            // Validate the user input to handle any potential input errors
            if (std::cin.fail()) {
                std::cin.clear(); // Clear the previous input
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Disregard the previous input
                std::cout << "Invalid input. Please enter a valid course number." << std::endl;
                break; // Break out of the switch case
            }

            // Find the course and print the details
            auto it = std::find_if(courses.begin(), courses.end(), [&](const Course& c) {
                return c.courseNumber == courseNum;
                });

            if (it != courses.end()) {
                // Course found, print the details
                std::cout << "Course Number: " << it->courseNumber << "\nTitle: " << it->title << std::endl;
                if (!it->prerequisites.empty()) {
                    std::cout << "Prerequisites: ";
                    for (const std::string& prereq : it->prerequisites) {
                        std::cout << prereq << " ";
                    }
                    std::cout << std::endl;
                }
            }
            else {
                std::cout << "Course not found." << std::endl;
            }
            break;  // Ensure to break from the case after the operation is complete
        }
        default:
            std::cout << option << " is not a valid option." << std::endl;
            break;
        }
    }

    std::cout << "Thank you for using the course planner!" << std::endl;
    return 0;
}
